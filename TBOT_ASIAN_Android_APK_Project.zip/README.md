# TBOT ASIAN - Android Auto Clicker & Accessibility Service
Para sa pagbuo ng APK (.apk):

## Paraan 1: Gamit ang GitHub Actions (Awtomatikong APK Download)
1. I-upload ang nilalaman ng folder na ito sa isang bagong GitHub repository.
2. Pumunta sa tab na "Actions" sa GitHub.
3. Awtomatikong tatakbo ang workflow na ".github/workflows/build-apk.yml".
4. Pagkatapos ng 2-3 minuto, i-click ang build artifact upang ma-download ang "app-debug.apk" o "app-release.apk" nang direkta sa iyong cellphone!

## Paraan 2: Gamit ang Android Studio (Computer)
1. Buksan ang Android Studio.
2. Piliin ang "Open" at piliin ang folder na ito.
3. Hintaying matapos ang Gradle sync.
4. Pumunta sa "Build" -> "Build Bundle(s) / APK(s)" -> "Build APK(s)".
5. Ang nalikhang APK ay makikita sa: app/build/outputs/apk/debug/app-debug.apk.

## Paraan 3: Gamit ang AIDE o Termux (Direkta sa Android Phone)
Maaari ring i-load ang proyektong ito sa AIDE (Android IDE) app mula sa Play Store para mag-compile ng APK mismo sa iyong Android phone nang walang PC!
