package com.tbot.asian.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AutoClickerAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoClickerAccessibilityService? = null
        var isClicking = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var clickRunnable: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopAutoClick()
    }

    fun startAutoClick(x: Float, y: Float, cps: Int, recoilPx: Float) {
        if (isClicking) return
        isClicking = true

        val intervalMs = (1000L / cps.coerceIn(1, 100)).coerceAtLeast(10L)
        var cycle = 0

        clickRunnable = object : Runnable {
            override fun run() {
                if (!isClicking) return

                val recoilOffset = (cycle % 4) * recoilPx
                val clickPath = Path().apply {
                    moveTo(x, y + recoilOffset)
                }

                val stroke = GestureDescription.StrokeDescription(clickPath, 0L, 8L)
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                dispatchGesture(gesture, null, null)

                cycle++
                handler.postDelayed(this, intervalMs)
            }
        }
        handler.post(clickRunnable!!)
    }

    fun stopAutoClick() {
        isClicking = false
        clickRunnable?.let { handler.removeCallbacks(it) }
        clickRunnable = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        stopAutoClick()
    }
}
