package com.tbot.asian.autoclicker

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(50, 80, 50, 50)
            setBackgroundColor(0xFF101010.toInt())
        }

        val btnAccessibility = Button(this).apply {
            text = "1. I-ON ANG ACCESSIBILITY SERVICE"
            setBackgroundColor(0xFF178a4c.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnOverlay = Button(this).apply {
            text = "2. I-ON ANG FLOATING OVERLAY"
            setBackgroundColor(0xFF178a4c.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    Toast.makeText(this@MainActivity, "Overlay Permission Granted!", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val btnStartWidget = Button(this).apply {
            text = "3. BUKSAN ANG FLOATING TBOT"
            setBackgroundColor(0xFF26884f.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                startService(Intent(this@MainActivity, FloatingWidgetService::class.java))
            }
        }

        layout.addView(btnAccessibility)
        layout.addView(btnOverlay)
        layout.addView(btnStartWidget)
        setContentView(layout)
    }
}
