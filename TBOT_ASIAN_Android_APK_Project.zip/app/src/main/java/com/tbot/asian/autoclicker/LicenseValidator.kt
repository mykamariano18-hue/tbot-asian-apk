package com.tbot.asian.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings

object LicenseValidator {

    @SuppressLint("HardwareIds")
    fun getHardwareDeviceId(context: Context): String {
        return Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        ) ?: "UNKNOWN_DEVICE_ID"
    }
}
