package com.tbot.asian.autoclicker

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.LinearLayout

class FloatingWidgetService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 250
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xDD181818.toInt())
            setPadding(20, 20, 20, 20)
        }

        val btnToggle = Button(this).apply {
            text = "START TBOT"
            setBackgroundColor(0xFF178a4c.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                if (AutoClickerAccessibilityService.isClicking) {
                    AutoClickerAccessibilityService.instance?.stopAutoClick()
                    text = "START TBOT"
                    setBackgroundColor(0xFF178a4c.toInt())
                } else {
                    AutoClickerAccessibilityService.instance?.startAutoClick(500f, 800f, 60, 2f)
                    text = "STOP TBOT"
                    setBackgroundColor(0xFFb52e37.toInt())
                }
            }
        }

        layout.addView(btnToggle)
        floatingView = layout
        windowManager.addView(floatingView, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { windowManager.removeView(it) }
    }
}
